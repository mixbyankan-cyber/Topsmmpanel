# Top SMM — Fresh Firebase Setup

The v45 files use only this project:

- Project ID: `top-smm`
- Realtime Database: `https://top-smm-default-rtdb.firebaseio.com/`
- Owner email expected by the Admin Panel: `a@gmail.com`

## Required Firebase Console steps

1. Open Firebase Console → `top-smm`.
2. Authentication → Sign-in method:
   - Enable **Email/Password**.
   - Enable **Google** if Google login is required.
3. Authentication → Users:
   - Create `a@gmail.com` with its new Admin password.
   - Old-project passwords/accounts are intentionally not migrated.
4. Authentication → Settings → Authorized domains:
   - Add the final Top SMM website domain.
5. Realtime Database:
   - Create the database.
   - Open **Rules**.
   - Paste the complete contents of `firebase-rules.json` and click **Publish**.
   - Root `.read: false` / `.write: false` is intentional default-deny; the child-path rules grant the exact access used by the website.
   - Do not paste only the first two root lines—the complete file is required.
   - All currently detected query indexes are included in the rules file.
6. Sign in to the Admin Panel once with `a@gmail.com` so the owner record can bootstrap under `admins/{uid}` if your rules permit owner bootstrap.
7. Admin Panel → General & Contact:
   - Set support email, WhatsApp and Telegram.
8. Add services, packages and payment methods. This is a fresh database, so old records will not appear.
9. Admin Panel → Email Settings:
   - Configure new EmailJS values if welcome email is required.

## Push notifications

The previous OneSignal App ID was intentionally removed. Push initialization is disabled until a new Top SMM OneSignal App ID is supplied.

## Important architecture note

The current project performs financial actions from browser-side Firebase transactions. Realtime Database Rules must be reviewed carefully. For production-grade wallet security, fund approval, order charging, refunds, coupon redemption and referral commissions should ultimately run in trusted Cloud Functions or another authenticated backend.

## Hosting note for `admin`

The requested Admin filename has no `.html` extension. Your hosting provider must serve `/admin` with MIME type `text/html`; otherwise the browser may download it instead of opening it.
